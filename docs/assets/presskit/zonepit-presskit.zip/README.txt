ZonePit – Press-Kit / Press kit

DE: Logos (SVG/PNG), App-Icon, Faktenblatt (PDF) und Textbausteine für redaktionelle Nutzung. Bitte Logo und Icon nicht verzerren, nicht umfärben und nicht mit anderen Elementen überlagern. Auf hellem Grund die Variante "on-light", auf dunklem Grund "on-dark" verwenden; einfarbig: "black" oder "white".

EN: Logos (SVG/PNG), app icon, fact sheet (PDF) and text blocks for editorial use. Please do not distort, recolor or overlay logo and icon. Use "on-light" on light backgrounds, "on-dark" on dark ones; single color: "black" or "white".

https://zonepit.github.io/
© Alexander Wolpert. 'Apple', 'iPhone', 'Apple Health' and 'Apple Intelligence' are trademarks of Apple Inc.
